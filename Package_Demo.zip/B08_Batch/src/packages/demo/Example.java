package packages.demo;

import com.tns.daythree.PackageDemo;

public class Example {

	public static void main(String[] args) {
		
		
		PackageDemo pd = new PackageDemo();
		pd.show();
		

	}

}
